package com.example.util

import android.content.Context
import android.content.pm.LauncherApps
import android.os.Handler
import android.os.Looper
import android.os.UserHandle

/**
 * Reports app installs, updates and removals (including work-profile apps) so the launcher can
 * refresh its app list without the user pressing Home. Callbacks arrive on the main thread.
 *
 * Call [start] once and [stop] when the owner (e.g. the ViewModel) is destroyed.
 */
class PackageChangeMonitor(
    context: Context,
    private val onPackagesChanged: (Collection<String>) -> Unit
) {
    private val launcherApps: LauncherApps? =
        context.applicationContext.getSystemService(LauncherApps::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private var isStarted = false

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageAdded(packageName: String, user: UserHandle) = report(packageName)
        override fun onPackageChanged(packageName: String, user: UserHandle) = report(packageName)
        override fun onPackageRemoved(packageName: String, user: UserHandle) = report(packageName)

        override fun onPackagesAvailable(
            packageNames: Array<out String>,
            user: UserHandle,
            replacing: Boolean
        ) = report(*packageNames)

        override fun onPackagesUnavailable(
            packageNames: Array<out String>,
            user: UserHandle,
            replacing: Boolean
        ) = report(*packageNames)
    }

    private fun report(vararg packageNames: String) {
        onPackagesChanged(packageNames.toList())
    }

    fun start() {
        if (isStarted) return
        try {
            launcherApps?.registerCallback(callback, handler)
            isStarted = launcherApps != null
        } catch (_: Throwable) {
            // Not fatal: the list still reloads when the user presses Home.
        }
    }

    fun stop() {
        if (!isStarted) return
        try {
            launcherApps?.unregisterCallback(callback)
        } catch (_: Throwable) {
        }
        isStarted = false
    }
}
