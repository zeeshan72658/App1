package com.example.data.db

import androidx.room.migration.Migration

/**
 * Every Room schema migration lives here. When you change an entity:
 *   1. bump `version` in [TaskLaunchDatabase],
 *   2. add a Migration below and list it in [ALL_MIGRATIONS].
 *
 * Example (v1 -> v2, new nullable column on the "tasks" table):
 *
 *   val MIGRATION_1_2 = object : Migration(1, 2) {
 *       override fun migrate(db: SupportSQLiteDatabase) {
 *           db.execSQL("ALTER TABLE tasks ADD COLUMN estimateMinutes INTEGER")
 *       }
 *   }
 *
 * Schema JSON files are exported to app/schemas/ on every build. Commit them: they are the
 * reference for writing (and testing) migrations.
 */
val ALL_MIGRATIONS: Array<Migration> = arrayOf()
